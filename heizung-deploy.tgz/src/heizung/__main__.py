"""Heizungssteuerung Hauptprogramm."""
from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import time
from dataclasses import replace
from typing import Any

from .lib.brauchwasser import BrauchwasserState, compute_brauchwasser
from .lib.brunnen import BrunnenPressureState, compute_brunnen_pressure
from .lib.config import AppConfig, ChannelConfig, ConfigError, IoMap, load_yaml, resolve_config_file
from .lib.failsafe import FailsafeMonitor, FailsafeState
from .lib.freigaben import Freigaben
from .lib.hand_auto import HandAutoManager
from .lib.intercpu import KellerModbusClient
from .lib.iohw import BaseIO, HardwareSnapshot, create_io_backend
from .lib.mqtt_bridge import MqttBridge
from .lib.regler import ReglerParameter
from .lib.routing import RoutingState, compute_routing
from .lib.state import StateStore
from .lib.tor import entscheide_tor_command

log = logging.getLogger("heizung")


async def run() -> int:
    """Hauptregelkreis."""
    try:
        app_config = AppConfig.load()
    except ConfigError as exc:
        log.error("Konfiguration ungueltig: %s", exc)
        return 2

    _apply_log_level(app_config.setting("logging.level", "INFO"))
    cycle_s = float(app_config.setting("regelung.fast_zyklus_ms", 100)) / 1000
    heating_divider = max(1, int(app_config.setting("regelung.heizung_divider", 10)))
    default_hand_timeout = app_config.setting("hand.default_timeout_min")
    hand_state_path = app_config.state_path(app_config.setting("hand.state_persist_path", "state/hand_state.json"))
    freigaben_state_path = app_config.state_path(app_config.setting("freigaben.state_persist_path", "state/freigaben.json"))
    regler_state_path = app_config.state_path(app_config.setting("regler.state_persist_path", "state/regler.json"))

    keller_client: KellerModbusClient | None = None
    controller_config = app_config
    keller_io_map = _load_keller_io_map(app_config) if _controller_role(app_config) == "haupt" else None
    if keller_io_map is not None and bool(app_config.setting("intercpu.keller.enabled", True)):
        host = str(app_config.setting("intercpu.keller.host", "10.1.25.11"))
        port = int(app_config.setting("intercpu.keller.port", 502))
        timeout_s = float(app_config.setting("intercpu.keller.timeout_s", 1.0))
        keller_client = KellerModbusClient(host, port, keller_io_map, timeout_s=timeout_s)
        controller_config = replace(app_config, io_map=_merge_io_maps(app_config.io_map, keller_io_map))
        log.info("Keller-Slave per Modbus aktiviert: %s:%s", host, port)

    io_backend = create_io_backend(app_config.io_map, os.environ.get("HEIZUNG_IO_BACKEND", "auto"))
    hand_auto = HandAutoManager(controller_config.io_map, StateStore(hand_state_path), default_hand_timeout)
    freigaben = Freigaben.from_settings(app_config.settings, StateStore(freigaben_state_path))
    regler = ReglerParameter.from_settings(app_config.settings, StateStore(regler_state_path))
    failsafe_monitor = FailsafeMonitor.from_settings(app_config.settings)
    mqtt = MqttBridge(app_config.mqtt)
    mqtt.set_default_demands(app_config.setting("anforderungen", {}))
    mqtt.start()

    log.info("Heizungssteuerung gestartet, schneller Zyklus %.3fs, Heizungsdivider %s", cycle_s, heating_divider)
    stop = asyncio.Event()
    boot_ts = time.time()

    def _handle_sig() -> None:
        log.info("Signal empfangen, beende ...")
        stop.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _handle_sig)
        except NotImplementedError:
            # Windows
            pass

    last_heartbeat_tick = -1
    ha_discovery_published = False
    cycle_count = 0
    brauchwasser_ladung_active = False
    brunnen_active = False
    brunnen_speed_pct = 0.0
    applied_do: dict[str, bool] = {}
    applied_ao: dict[str, float] = {}
    try:
        while not stop.is_set():
            started = time.monotonic()
            now_ts = time.time()
            if mqtt.connected and not ha_discovery_published:
                _publish_ha_discovery(mqtt, controller_config)
                ha_discovery_published = True

            snapshot = await io_backend.read_all()
            if keller_client is not None:
                try:
                    keller_snapshot = await keller_client.read_snapshot()
                    snapshot = _merge_snapshots(snapshot, keller_snapshot)
                    mqtt.peer_last_seen_ts = now_ts
                    mqtt.peer_online = True
                except Exception as exc:
                    mqtt.peer_online = False
                    log.warning("Keller-Slave Modbus nicht erreichbar: %s", exc)
            await _handle_mqtt_commands(
                mqtt,
                controller_config,
                hand_auto,
                freigaben,
                regler,
                failsafe_monitor,
                io_backend,
                snapshot,
                now_ts,
            )

            failsafe_state = failsafe_monitor.evaluate(
                now_ts=now_ts,
                mqtt_connected=mqtt.connected,
                last_mqtt_seen_ts=mqtt.last_seen_ts,
                last_ha_heartbeat_ts=mqtt.last_ha_heartbeat_ts,
                outside_temp_c=_sensor_value_by_component(controller_config, snapshot, "aussen"),
            )

            heating_tick = cycle_count % heating_divider == 0
            if heating_tick:
                routing_state, brauchwasser_state, brunnen_state, auto_do, auto_ao = _compute_auto_outputs(
                    controller_config,
                    mqtt,
                    snapshot,
                    failsafe_state,
                    freigaben,
                    regler,
                    brauchwasser_ladung_active,
                    brunnen_active,
                    brunnen_speed_pct,
                    cycle_s,
                )
                brauchwasser_ladung_active = brauchwasser_state.active
            else:
                brunnen_state = _compute_fast_brunnen_outputs(
                    controller_config,
                    snapshot,
                    regler,
                    brunnen_active,
                    brunnen_speed_pct,
                    cycle_s,
                    auto_do,
                    auto_ao,
                )
            brunnen_active = brunnen_state.active
            brunnen_speed_pct = brunnen_state.speed_pct
            write_only = None if heating_tick else _brunnen_output_ids(controller_config)
            written_do, written_ao = await _write_outputs(
                controller_config,
                app_config.io_map,
                io_backend,
                hand_auto,
                auto_do,
                auto_ao,
                now_ts,
                keller_client,
                only_channel_ids=write_only,
                keller_fallback_do=applied_do,
                keller_fallback_ao=applied_ao,
            )
            applied_do.update(written_do)
            applied_ao.update(written_ao)
            if keller_client is not None and mqtt.peer_online is not False:
                mqtt.peer_last_seen_ts = now_ts
                mqtt.peer_online = True

            if heating_tick:
                _publish_state(
                    mqtt,
                    controller_config,
                    snapshot,
                    failsafe_state,
                    hand_auto,
                    freigaben,
                    regler,
                    routing_state,
                    brauchwasser_state,
                    brunnen_state,
                    applied_do,
                    applied_ao,
                )
            uptime_s = int(now_ts - boot_ts)
            heartbeat_tick = uptime_s // 30
            if heartbeat_tick != last_heartbeat_tick:
                last_heartbeat_tick = heartbeat_tick
                mqtt.publish_heartbeat(uptime_s)

            cycle_count += 1
            await _update_cpu_leds(
                io_backend,
                app_config,
                mqtt,
                failsafe_state,
                now_ts,
                boot_ts,
                cycle_count // max(1, heating_divider // 2),
            )

            await _sleep_remaining(stop, cycle_s, started)
    finally:
        await io_backend.set_cpu_leds({"A1": "off", "A2": "off", "A3": "off", "A4": "off", "A5": "off"})
        mqtt.stop()
        await io_backend.close()

    log.info("Heizungssteuerung beendet")
    return 0


async def _sleep_remaining(stop: asyncio.Event, cycle_s: float, started: float) -> None:
    remaining = max(0.0, cycle_s - (time.monotonic() - started))
    try:
        await asyncio.wait_for(stop.wait(), timeout=remaining)
    except TimeoutError:
        return


def _load_keller_io_map(app_config: AppConfig) -> IoMap | None:
    try:
        raw = load_yaml(resolve_config_file(app_config.config_dir, "io_map.keller.yaml"))
    except ConfigError:
        return None
    return IoMap.from_dict(raw)


def _merge_io_maps(main: IoMap, keller: IoMap) -> IoMap:
    return IoMap(
        revpi=dict(main.revpi),
        do={**main.do, **keller.do},
        di={**main.di, **keller.di},
        ai={**main.ai, **keller.ai},
        ao={**main.ao, **keller.ao},
        rtd={**main.rtd, **keller.rtd},
    )


def _merge_snapshots(main: HardwareSnapshot, keller: HardwareSnapshot) -> HardwareSnapshot:
    return HardwareSnapshot(
        di={**main.di, **keller.di},
        ai={**main.ai, **keller.ai},
        rtd={**main.rtd, **keller.rtd},
        do={**main.do, **keller.do},
        ao={**main.ao, **keller.ao},
    )


async def _update_cpu_leds(
    io_backend: BaseIO,
    app_config: AppConfig,
    mqtt: MqttBridge,
    failsafe_state: FailsafeState,
    now_ts: float,
    boot_ts: float,
    cycle_count: int,
) -> None:
    settings = app_config.setting("leds", {})
    if isinstance(settings, dict) and settings.get("enabled") is False:
        return

    role = _controller_role(app_config)
    peer_timeout_s = float((settings or {}).get("peer_timeout_s", 90) if isinstance(settings, dict) else 90)
    heartbeat_interval_s = float(
        (settings or {}).get("heartbeat_interval_s", 1.0) if isinstance(settings, dict) else 1.0
    )
    ha_timeout_s = float(app_config.setting("failsafe.ha_heartbeat_timeout_s", 300))
    ha_required = bool(app_config.setting("failsafe.ha_heartbeat_required", False))

    colors = {
        "A1": _heartbeat_led_color(now_ts, boot_ts, heartbeat_interval_s),
        "A2": _peer_led_color(mqtt, now_ts, boot_ts, peer_timeout_s),
    }
    if role == "haupt":
        colors.update(
            {
                "A3": "green" if mqtt.connected else "red",
                "A4": _freshness_led_color(mqtt.last_ha_heartbeat_ts, now_ts, ha_timeout_s, required=ha_required),
                "A5": "red" if failsafe_state.active else "green",
            }
        )
    else:
        colors.update({"A3": "off", "A4": "off", "A5": "off"})

    await io_backend.set_cpu_leds(colors)


def _heartbeat_led_color(now_ts: float, boot_ts: float, interval_s: float) -> str:
    interval_s = max(0.2, float(interval_s))
    return "blue" if int((now_ts - boot_ts) / interval_s) % 2 else "yellow"


def _controller_role(app_config: AppConfig) -> str:
    leds = app_config.mqtt.get("leds", {})
    if isinstance(leds, dict) and leds.get("role"):
        role = str(leds["role"]).strip().lower()
        if role in {"haupt", "main"}:
            return "haupt"
        if role in {"keller", "slave"}:
            return "keller"

    client_id = str(app_config.mqtt.get("broker", {}).get("client_id", "")).lower()
    hostname = str(app_config.io_map.revpi.get("hostname", "")).lower()
    if "keller" in client_id or hostname.endswith("107293"):
        return "keller"
    return "haupt"


def _peer_led_color(mqtt: MqttBridge, now_ts: float, boot_ts: float, timeout_s: float) -> str:
    if mqtt.peer_last_seen_ts is not None and now_ts - mqtt.peer_last_seen_ts <= timeout_s and mqtt.peer_online is not False:
        return "green"
    if now_ts - boot_ts < timeout_s:
        return "yellow"
    return "red"


def _freshness_led_color(last_seen_ts: float | None, now_ts: float, timeout_s: float, *, required: bool) -> str:
    if last_seen_ts is not None and now_ts - last_seen_ts <= timeout_s:
        return "green"
    return "red" if required else "yellow"


async def _handle_mqtt_commands(
    mqtt: MqttBridge,
    app_config: AppConfig,
    hand_auto: HandAutoManager,
    freigaben: Freigaben,
    regler: ReglerParameter,
    failsafe_monitor: FailsafeMonitor,
    io_backend: BaseIO,
    snapshot: HardwareSnapshot,
    now_ts: float,
) -> None:
    for command in mqtt.drain_commands():
        if command.typ == "failsafe_force":
            failsafe_monitor.force = str(command.payload).strip().lower() in {"1", "true", "on", "ja"}
            continue

        if command.typ == "freigabe_set":
            group, _, name = command.name.partition("/")
            if not freigaben.set(group, name, _extract_bool(command.payload)):
                log.warning("MQTT-Freigabe fuer unbekannte Gruppe/Komponente ignoriert: %s", command.name)
            continue

        if command.typ == "regler_set":
            if not regler.set(command.name, command.payload):
                log.warning("MQTT-Reglerparameter unbekannt, ignoriert: %s", command.name)
            continue

        if command.typ == "tor_command":
            await _handle_tor_command(app_config, io_backend, snapshot, command.name)
            continue

        channel = app_config.io_map.by_component(command.name)
        if channel is None:
            log.warning("MQTT-Kommando fuer unbekannte Komponente ignoriert: %s", command.name)
            continue
        log.info("MQTT-Kommando verarbeitet: typ=%s komponente=%s kanal=%s kind=%s", command.typ, command.name, channel.id, channel.kind)

        if command.typ == "hand_set":
            wert = _extract_hand_value(command.payload)
            hand_auto.set_hand(channel.id, _coerce_output_value(channel, wert), now_ts)
        elif command.typ == "hand_auto":
            hand_auto.set_auto(channel.id)
        elif command.typ == "pulse" and channel.kind == "do":
            duration_ms = channel.impuls_ms or 250
            log.info("Pulse Ausgang %s (%s) fuer %sms", channel.id, channel.komponente, duration_ms)
            await io_backend.pulse(channel, duration_ms)


async def _handle_tor_command(
    app_config: AppConfig,
    io_backend: BaseIO,
    snapshot: HardwareSnapshot,
    command_name: str,
) -> None:
    links_zu = _di_value_by_component(app_config, snapshot, "tor_fluegel_links_zu", "tor_es_ganz_zu")
    rechts_zu = _di_value_by_component(app_config, snapshot, "tor_fluegel_rechts_zu", "tor_es_halb_zu")
    decision = entscheide_tor_command(command_name, links_zu, rechts_zu)
    log.info(
        "Torbefehl %s: links_zu=%s rechts_zu=%s ausgang=%s ausfuehren=%s grund=%s",
        command_name,
        links_zu,
        rechts_zu,
        decision.ausgang,
        decision.ausfuehren,
        decision.grund,
    )
    if not decision.ausfuehren or decision.ausgang is None:
        return
    channel = app_config.io_map.by_component(decision.ausgang)
    if channel is None or channel.kind != "do":
        log.warning("Torbefehl %s kann Ausgang %s nicht finden", command_name, decision.ausgang)
        return
    await io_backend.pulse(channel, channel.impuls_ms or 1000)


def _extract_hand_value(payload: Any) -> Any:
    if isinstance(payload, dict):
        if payload.get("hand") is False:
            return False
        return payload.get("wert", payload.get("value", True))
    if isinstance(payload, str):
        lowered = payload.strip().lower()
        if lowered in {"1", "true", "on", "ja"}:
            return True
        if lowered in {"0", "false", "off", "nein"}:
            return False
    return payload


def _compute_auto_outputs(
    app_config: AppConfig,
    mqtt: MqttBridge,
    snapshot: HardwareSnapshot,
    failsafe_state: FailsafeState,
    freigaben: Freigaben,
    regler: ReglerParameter,
    brauchwasser_previous_active: bool,
    brunnen_previous_active: bool,
    brunnen_previous_speed_pct: float,
    cycle_s: float = 1.0,
) -> tuple[RoutingState, BrauchwasserState, BrunnenPressureState, dict[str, bool], dict[str, float]]:
    routing_state, routed_do, routed_ao = compute_routing(
        regler.as_settings(app_config.settings),
        mqtt.demands,
        failsafe_state,
        freigaben,
    )
    auto = {channel_id: False for channel_id in app_config.io_map.do}
    for channel_id, value in routed_do.items():
        if channel_id in auto:
            auto[channel_id] = value
    brauchwasser_state = compute_brauchwasser(
        app_config,
        snapshot,
        freigaben,
        regler,
        brauchwasser_previous_active,
    )
    if "DO01" in auto:
        auto["DO01"] = auto["DO01"] or brauchwasser_state.active
    if "DO02" in auto:
        auto["DO02"] = brauchwasser_state.active

    brunnen_state = compute_brunnen_pressure(
        app_config,
        snapshot,
        regler,
        brunnen_previous_active,
        brunnen_previous_speed_pct,
        cycle_s,
    )
    brunnen_do = app_config.io_map.by_component("brunnen_pumpe_freigabe")
    if brunnen_do is not None and brunnen_do.kind == "do" and brunnen_do.id in auto:
        auto[brunnen_do.id] = brunnen_state.active

    auto_ao = {channel_id: 0.0 for channel_id in app_config.io_map.ao}
    for channel_id, value in routed_ao.items():
        if channel_id in auto_ao:
            auto_ao[channel_id] = value
    brunnen_ao = app_config.io_map.by_component("brunnen_fu_soll")
    if brunnen_ao is not None and brunnen_ao.kind == "ao" and brunnen_ao.id in auto_ao:
        auto_ao[brunnen_ao.id] = brunnen_state.speed_pct
    return routing_state, brauchwasser_state, brunnen_state, auto, auto_ao


def _compute_fast_brunnen_outputs(
    app_config: AppConfig,
    snapshot: HardwareSnapshot,
    regler: ReglerParameter,
    brunnen_previous_active: bool,
    brunnen_previous_speed_pct: float,
    cycle_s: float,
    auto_do: dict[str, bool],
    auto_ao: dict[str, float],
) -> BrunnenPressureState:
    brunnen_state = compute_brunnen_pressure(
        app_config,
        snapshot,
        regler,
        brunnen_previous_active,
        brunnen_previous_speed_pct,
        cycle_s,
    )
    brunnen_do = app_config.io_map.by_component("brunnen_pumpe_freigabe")
    if brunnen_do is not None and brunnen_do.kind == "do" and brunnen_do.id in auto_do:
        auto_do[brunnen_do.id] = brunnen_state.active
    brunnen_ao = app_config.io_map.by_component("brunnen_fu_soll")
    if brunnen_ao is not None and brunnen_ao.kind == "ao" and brunnen_ao.id in auto_ao:
        auto_ao[brunnen_ao.id] = brunnen_state.speed_pct
    return brunnen_state


def _brunnen_output_ids(app_config: AppConfig) -> set[str]:
    ids: set[str] = set()
    for component in ("brunnen_pumpe_freigabe", "brunnen_fu_soll"):
        channel = app_config.io_map.by_component(component)
        if channel is not None and channel.kind in {"do", "ao"}:
            ids.add(channel.id)
    return ids


async def _write_outputs(
    app_config: AppConfig,
    local_io_map: IoMap,
    io_backend: BaseIO,
    hand_auto: HandAutoManager,
    auto_do: dict[str, bool],
    auto_ao: dict[str, float],
    now_ts: float,
    keller_client: KellerModbusClient | None = None,
    only_channel_ids: set[str] | None = None,
    keller_fallback_do: dict[str, bool] | None = None,
    keller_fallback_ao: dict[str, float] | None = None,
) -> tuple[dict[str, bool], dict[str, float]]:
    applied_do: dict[str, bool] = {}
    applied_ao: dict[str, float] = {}
    keller_do: dict[str, bool] = {}
    keller_ao: dict[str, float] = {}
    for channel_id, channel in app_config.io_map.do.items():
        if only_channel_ids is not None and channel_id not in only_channel_ids:
            continue
        value, _hand = hand_auto.apply(channel, auto_do.get(channel_id, False), now_ts)
        applied_do[channel_id] = bool(value)
        if channel_id in local_io_map.do:
            await io_backend.write_do(channel, applied_do[channel_id])
        else:
            keller_do[channel_id] = applied_do[channel_id]

    for channel_id, channel in app_config.io_map.ao.items():
        if only_channel_ids is not None and channel_id not in only_channel_ids:
            continue
        value, _hand = hand_auto.apply(channel, auto_ao.get(channel_id, 0.0), now_ts)
        applied_ao[channel_id] = float(value)
        if channel_id in local_io_map.ao:
            await io_backend.write_ao(channel, applied_ao[channel_id])
        else:
            keller_ao[channel_id] = applied_ao[channel_id]

    if keller_client is not None and (keller_do or keller_ao):
        for channel_id in keller_client.io_map.do:
            keller_do.setdefault(channel_id, (keller_fallback_do or {}).get(channel_id, auto_do.get(channel_id, False)))
        for channel_id in keller_client.io_map.ao:
            keller_ao.setdefault(channel_id, (keller_fallback_ao or {}).get(channel_id, auto_ao.get(channel_id, 0.0)))
        try:
            await keller_client.write_outputs(keller_do, keller_ao, enabled=True)
        except Exception as exc:
            log.warning("Keller-Slave Modbus Schreiben fehlgeschlagen: %s", exc)
    return applied_do, applied_ao


def _publish_state(
    mqtt: MqttBridge,
    app_config: AppConfig,
    snapshot: HardwareSnapshot,
    failsafe_state: FailsafeState,
    hand_auto: HandAutoManager,
    freigaben: Freigaben,
    regler: ReglerParameter,
    routing_state: RoutingState,
    brauchwasser_state: BrauchwasserState,
    brunnen_state: BrunnenPressureState,
    applied_do: dict[str, bool],
    applied_ao: dict[str, float],
) -> None:
    base = mqtt.base
    mqtt.publish(f"{base}/failsafe/active", "1" if failsafe_state.active else "0", retain=True)
    mqtt.publish(f"{base}/failsafe/grund", ",".join(failsafe_state.reasons), retain=True)
    if failsafe_state.vl_soll is not None:
        mqtt.publish(f"{base}/vl_soll/state", f"{failsafe_state.vl_soll:.1f}", retain=True)
    if routing_state.vl_soll is not None:
        mqtt.publish(f"{base}/gesamt/vl_soll/state", f"{routing_state.vl_soll:.1f}", retain=True)
    mqtt.publish(f"{base}/gesamt/active", "1" if routing_state.common_active else "0", retain=True)
    mqtt.publish_json(f"{base}/routing/state", routing_state.as_payload(), retain=True)
    mqtt.publish(f"{base}/brauchwasser/ladung_aktiv", "1" if brauchwasser_state.active else "0", retain=True)
    mqtt.publish(f"{base}/brauchwasser/grund", brauchwasser_state.reason, retain=True)
    mqtt.publish_json(f"{base}/brauchwasser/state", brauchwasser_state.as_payload(), retain=True)
    mqtt.publish(f"{base}/brunnen/active", "1" if brunnen_state.active else "0", retain=True)
    mqtt.publish(f"{base}/brunnen/grund", brunnen_state.reason, retain=True)
    mqtt.publish(f"{base}/brunnen/druck_bar/state", "" if brunnen_state.pressure_bar is None else f"{brunnen_state.pressure_bar:.2f}", retain=True)
    mqtt.publish(f"{base}/brunnen/fu_soll_pct/state", f"{brunnen_state.speed_pct:.1f}", retain=True)
    mqtt.publish_json(f"{base}/brunnen/state", brunnen_state.as_payload(), retain=True)
    for name, active in sorted(mqtt.pv.items()):
        mqtt.publish(f"{base}/pv/{name}/state", "1" if active else "0", retain=True)
    mqtt.publish_json(f"{base}/freigabe/state", freigaben.snapshot(), retain=True)
    mqtt.publish_json(f"{base}/regler/state", regler.snapshot(), retain=True)
    for name, value in regler.snapshot().items():
        mqtt.publish(f"{base}/regler/{name}/state", str(value), retain=True)

    for name, enabled in freigaben.sources.items():
        mqtt.publish(f"{base}/freigabe/quellen/{name}/state", "1" if enabled else "0", retain=True)
    for name, enabled in freigaben.sinks.items():
        mqtt.publish(f"{base}/freigabe/senken/{name}/state", "1" if enabled else "0", retain=True)

    for name, demand in mqtt.demands.items():
        mqtt.publish_json(
            f"{base}/anforderung/{name}/aktuell",
            {"aktiv": demand.aktiv, "vl_soll": demand.vl_soll, "quelle": demand.quelle},
            retain=True,
        )
        mqtt.publish(f"{base}/anforderung/{name}/aktiv/state", "1" if demand.aktiv else "0", retain=True)
        if demand.vl_soll is not None:
            mqtt.publish(f"{base}/anforderung/{name}/vl_soll/state", f"{demand.vl_soll:.1f}", retain=True)

    for channel_id, channel in app_config.io_map.ai.items():
        value = snapshot.ai.get(channel_id)
        if value is not None:
            mqtt.publish(f"{base}/temp/{channel.komponente}/state", f"{value:.1f}")

    for channel_id, channel in app_config.io_map.rtd.items():
        value = snapshot.rtd.get(channel_id)
        if value is not None:
            mqtt.publish(f"{base}/temp/{channel.komponente}/state", f"{value:.1f}")

    for channel_id, channel in app_config.io_map.di.items():
        value = snapshot.di.get(channel_id)
        if value is not None:
            mqtt.publish(f"{base}/di/{channel.komponente}/state", "1" if value else "0")

    mqtt.publish_json(f"{base}/hand/state", hand_auto.snapshot(), retain=True)
    hand_snapshot = hand_auto.snapshot()
    for channel_id, channel in app_config.io_map.do.items():
        value = applied_do.get(channel_id, False)
        hand = hand_snapshot.get(channel_id)
        mqtt.publish(f"{base}/do/{channel.komponente}/state", "1" if value else "0", retain=True)
        mqtt.publish(f"{base}/{channel.komponente}/hand/mode/state", "1" if hand else "0", retain=True)
        mqtt.publish(f"{base}/{channel.komponente}/hand/value/state", "1" if (hand or {}).get("wert") else "0", retain=True)
    for channel_id, channel in app_config.io_map.ao.items():
        value = applied_ao.get(channel_id, 0.0)
        hand = hand_snapshot.get(channel_id)
        mqtt.publish(f"{base}/ao/{channel.komponente}/state", f"{value:.1f}", retain=True)
        mqtt.publish(f"{base}/{channel.komponente}/hand/mode/state", "1" if hand else "0", retain=True)
        mqtt.publish(f"{base}/{channel.komponente}/hand/value/state", str((hand or {}).get("wert", 0.0)), retain=True)


def _publish_ha_discovery(mqtt: MqttBridge, app_config: AppConfig) -> None:
    discovery = app_config.mqtt.get("ha_discovery", {})
    if discovery.get("enabled", True) is False:
        return
    prefix = str(discovery.get("prefix", "homeassistant")).strip("/")
    device = discovery.get("device", {})
    if not isinstance(device, dict):
        device = {}
    device_payload = {
        "identifiers": device.get("identifiers", ["heizung-haupt"]),
        "name": device.get("name", "Heizung Hauptsteuerung"),
        "model": device.get("model", "RevPi Connect 4"),
        "manufacturer": device.get("manufacturer", "Freezweb"),
        "sw_version": device.get("sw_version", "0.0.1"),
    }

    for channel in app_config.io_map.do.values():
        _publish_discovery_entity(
            mqtt,
            prefix,
            "binary_sensor",
            f"ausgang_{channel.komponente}",
            {
                "name": f"Ausgang {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/do/{channel.komponente}/state",
                "payload_on": "1",
                "payload_off": "0",
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "binary_sensor",
            f"hand_aktiv_{channel.komponente}",
            {
                "name": f"Hand aktiv {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/{channel.komponente}/hand/mode/state",
                "payload_on": "1",
                "payload_off": "0",
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "switch",
            f"handwert_{channel.komponente}",
            {
                "name": f"Handwert {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/{channel.komponente}/hand/value/state",
                "command_topic": f"{mqtt.base}/{channel.komponente}/hand/set",
                "payload_on": "1",
                "payload_off": "0",
                "state_on": "1",
                "state_off": "0",
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "button",
            f"auto_{channel.komponente}",
            {
                "name": f"Auto {_display_name(channel)}",
                "command_topic": f"{mqtt.base}/{channel.komponente}/hand/auto",
                "payload_press": "1",
                "device": device_payload,
            },
        )

    for channel in app_config.io_map.ao.values():
        unit = channel.einheit or "%"
        low, high = channel.bereich or (0.0, 100.0)
        _publish_discovery_entity(
            mqtt,
            prefix,
            "sensor",
            f"ausgang_{channel.komponente}",
            {
                "name": f"Ausgang {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/ao/{channel.komponente}/state",
                "unit_of_measurement": unit,
                "state_class": "measurement",
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "binary_sensor",
            f"hand_aktiv_{channel.komponente}",
            {
                "name": f"Hand aktiv {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/{channel.komponente}/hand/mode/state",
                "payload_on": "1",
                "payload_off": "0",
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "number",
            f"handwert_{channel.komponente}",
            {
                "name": f"Handwert {_display_name(channel)}",
                "state_topic": f"{mqtt.base}/{channel.komponente}/hand/value/state",
                "command_topic": f"{mqtt.base}/{channel.komponente}/hand/set",
                "min": low,
                "max": high,
                "step": 0.1,
                "mode": "box",
                "unit_of_measurement": unit,
                "device": device_payload,
            },
        )
        _publish_discovery_entity(
            mqtt,
            prefix,
            "button",
            f"auto_{channel.komponente}",
            {
                "name": f"Auto {_display_name(channel)}",
                "command_topic": f"{mqtt.base}/{channel.komponente}/hand/auto",
                "payload_press": "1",
                "device": device_payload,
            },
        )
    log.info("Home-Assistant MQTT-Discovery publiziert")


def _publish_discovery_entity(
    mqtt: MqttBridge,
    prefix: str,
    component: str,
    object_name: str,
    payload: dict[str, Any],
) -> None:
    unique_id = f"heizung_hauptsteuerung_{object_name}"
    entity_payload = {
        **payload,
        "unique_id": unique_id,
        "object_id": unique_id,
        "availability_topic": f"{mqtt.base}/status",
        "payload_available": "online",
        "payload_not_available": "offline",
    }
    mqtt.publish_json(f"{prefix}/{component}/{unique_id}/config", entity_payload, retain=True)


def _display_name(channel: ChannelConfig) -> str:
    if channel.beschreibung:
        return channel.beschreibung
    return channel.komponente.replace("_", " ").title()


def _coerce_output_value(channel: ChannelConfig, value: Any) -> Any:
    if channel.kind == "do":
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "on", "ja"}
        return bool(value)
    if isinstance(value, str):
        value = value.replace(",", ".")
    return float(value)


def _extract_bool(payload: Any) -> bool:
    if isinstance(payload, dict):
        for key in ("enabled", "freigabe", "aktiv", "value", "state"):
            if key in payload:
                return _extract_bool(payload[key])
        return bool(payload)
    if isinstance(payload, str):
        return payload.strip().lower() in {"1", "true", "on", "yes", "ja", "ein"}
    return bool(payload)


def _sensor_value_by_component(app_config: AppConfig, snapshot: HardwareSnapshot, component: str) -> float | None:
    for channel_id, channel in app_config.io_map.rtd.items():
        if channel.komponente == component:
            return snapshot.rtd.get(channel_id)
    for channel_id, channel in app_config.io_map.ai.items():
        if channel.komponente == component:
            return snapshot.ai.get(channel_id)
    return None


def _di_value_by_component(app_config: AppConfig, snapshot: HardwareSnapshot, *components: str) -> bool | None:
    for channel_id, channel in app_config.io_map.di.items():
        if channel.komponente in components:
            return snapshot.di.get(channel_id)
    return None


def _apply_log_level(level_name: str) -> None:
    level = getattr(logging, str(level_name).upper(), logging.INFO)
    logging.getLogger().setLevel(level)


def main() -> int:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        stream=sys.stderr,
    )
    return asyncio.run(run())


if __name__ == "__main__":
    raise SystemExit(main())
